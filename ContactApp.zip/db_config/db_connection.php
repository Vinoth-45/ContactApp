<?php

$db['db_host'] = "localhost";
$db['db_user'] = "root";
$db['db_pass'] = "";
$db['db_name'] = "contactapp";


foreach($db as $key => $value)
{
    define(strtoupper($key),$value);
}

$mysql = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

?>